import { Component } from '@angular/core';

@Component({
  selector: 'app-medicaltips',
  standalone: true,
  imports: [],
  templateUrl: './medicaltips.component.html',
  styleUrl: './medicaltips.component.css'
})
export class MedicaltipsComponent {

}
